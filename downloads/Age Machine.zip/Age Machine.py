# Calculate the Age of the User
from datetime import datetime
# Main loop to allow restarting the program
while True:
# Loop to ensure valid username input
    while True:
        username_1 = input("Enter Your username Here:\t")
# Exit loop if username is valid (not empty)
        if username_1.strip():
            break
        print("Invalid Input!! Try Again..")
    dob_input = input("Enter your date of birth (DD-MM-YYYY):\t")
    dob = datetime.strptime(dob_input, "%d-%m-%Y")
    today = datetime.today()
# Seprator Used To Separate Between The Login And The Operation User Wants To Do
    print("-------------------------")
# Display menu options to the user
    print(" What You Want To Know??\n 1 - Know Your Age \n 2- Know How many Days You Lived\n 3 - Know How Far Is Your Birthday Day From Today \n 4 - Compare Your Age")
# Get user's choice
    cal_1 = int(input("Enter a Value(1/2/3/4):\t"))
# Restart loop if input is invalid
    if cal_1 not in (1, 2, 3, 4):
        print("Invalid Input. Try Again!!")
        continue
# Calculate user's age in years
    if cal_1 == 1:
        age_years = today.year - dob.year
        age_months = today.month - dob.month
        age_days = today.day - dob.day
        # Adjust if birthday hasn't occurred yet this year
        if age_months < 0 or (age_months == 0 and age_days < 0):
            age_years -= 1
        print(f"You are {age_years} years old.")
# Calculate total days lived
    elif cal_1 == 2:
        days_lived = (today - dob).days
        print(f"You have lived for {days_lived} days.")
# Calculate days until next birthday
    elif cal_1 == 3:
        next_birthday = dob.replace(year=today.year)
        if next_birthday < today:
            next_birthday = next_birthday.replace(year=today.year + 1)
        days_left = (next_birthday - today).days
        print(f"Your next birthday is in {days_left} days.")
# Compare ages of two people
    elif cal_1 == 4:
        name_1 = input("Enter Name of First Person:\t")
        ask_input1 = input("Enter Date Of Birth Of First Person (DD-MM-YYYY):\t")
        ask_1 = datetime.strptime(ask_input1, "%d-%m-%Y")
        print(ask_1.strftime("%d-%m-%Y"))
        name_2 = input("Enter Name of Second Person:\t")
        ask_input2 = input("Enter Date Of Birth Of Second Person (DD-MM-YYYY):\t")
        ask_2 = datetime.strptime(ask_input2, "%d-%m-%Y")
        print(ask_2.strftime("%d-%m-%Y"))

        if ask_1 < ask_2:
            differ_1 = (ask_2 - ask_1).days
            print(name_1, "is Older Than", name_2, f"by {differ_1} days")

        elif ask_2 < ask_1:
            differ_1 = (ask_1 - ask_2).days
            print(name_2, "is Older Than", name_1, f"by {differ_1} days")

        else:
            print(f"{name_1} and {name_2} are of the same age.")
# Ask user if they want to restart
    again = input("Do you want to start again? (y/n): ").strip().lower()
# Exit the main loop and end the program
    if again != 'y':
        print(" Thank You For Using Age Machine!!\n Hope You Enjoyed It.. ")
        break
# Thanks Note at the End