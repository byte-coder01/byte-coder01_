# log in for the number guessing game
name = input("Enter your name:\t")
age = int(input("Enter your age(year):\t"))
if age < 13:
    print("You cannot play this game as you may get addicted to it.")
else:
    print("Welcome to the number guessing game", name,"!!")
    ask_level = input(
        "------------------------------------------------------------\n"
        " Easy level(E)\n"
        " Medium level(M)\n"
        " Hard level(H)\n"
        " Which level Do you want to play?:(H/M/E):\t"
    ).upper()
    if ask_level == 'H':
        import random
        # Number Guessing Game(Hard level)
        x = random.randint(1, 100)
        print(x)
        while True:
            i_1 = int(input("Guess a number between 1 and 100:\t"))
            if i_1 < x:
                print("Your guess is too low. Try again.")
            elif i_1 > x:
                print("Your guess is too high. Try again.")
            else:
                print("------------------------------------------------------------")
                print("Congratulations! You guessed the number correctly.")
                print("------------------------------------------------------------")
                break
    elif ask_level == 'M':
        import random
        # Number Guessing Game(Medium level)
        x = random.randint(1, 50)
        while True:
            i_1 = int(input("Guess a number between 1 and 50:\t"))
            if i_1 < x:
                print("Your guess is too low. Try again.")
            elif i_1 > x:
                print("Your guess is too high. Try again.")
            else:
                print("------------------------------------------------------------")
                print("Congratulations! You guessed the number correctly.")
                print("------------------------------------------------------------")
                break
    elif ask_level == 'E':
        import random
        # Number Guessing Game(Easy level)
        x = random.randint(1, 25)
        while True:
            i_1 = int(input("Guess a number between 1 and 25:\t"))
            if i_1 < x:
                print("Your guess is too low. Try again.")
            elif i_1 > x:
                print("Invalid Input! Please enter H for Hard, M for Medium, or E for Easy level. Try Again...")
            else:
                print("------------------------------------------------------------")
                print("Congratulations! You guessed the number correctly.")
                print("------------------------------------------------------------")
                break
    else:
        print("Invalid Input!! Try Again...")