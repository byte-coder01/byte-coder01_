# programme of table generator 
# ask user to make which number's table
import time
x= int(input("Enter Number Of Which You Want To Generate Table:\t"))#2
# ask user to make number's table till where
y= int(input("Enter Till Where You Want To Genrate Table:\t"))#2
for i in range(1,y+1):# range(a,b) here b will be excluded and a will be included   
    print(i,"x",x,"=",x*i)
ask_1 = input("Do you want to generate another table? (y/n): ")
if ask_1.lower() != 'y':    
    print("Exiting Table Generator...")
    time.sleep(4)
    print("Table Generator Exited Successfully!!!!")
    print("Thank You For Using Table Generator!")
    exit()
time.sleep(4)
time.sleep(2)
print("Re-Connecting To The Server....")
time.sleep(4)

while True:
    x= int(input("Enter Number Of Which You Want To Generate Table:\t"))#2
    # ask user to make number's table till where
    y= int(input("Enter Till Where You Want To Genrate Table:\t"))#2
    for i in range(1,y+1):# range(a,b) here b will be excluded and a will be included   
        print(i,"x",x,"=",x*i)
    ask_1 = input("Do you want to generate another table? (y/n): ")
    if ask_1.lower() != 'y':    
        print("Exiting Table Generator...")
        time.sleep(4)
        print("Table Generator Exited Successfully!!!!")
        print("Thank You For Using Table Generator!")
        exit()
        time.sleep(1)
        print("Re-Connecting To The Server....")
        time.sleep(2)