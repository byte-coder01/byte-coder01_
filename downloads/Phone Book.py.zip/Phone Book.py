#Contact book

inter_code ={
    "+91":"India",
    "+92":"Pakistan"
}

contacts = {
}

def add_contact():
    name = input("Enter the name for the contact : ")
    intl_code = input("Enter the international code (eg.= +91) : ")
    contact = input("Enter the number : ")
    if len(contact) != 10 or not contact.isdigit():
        print("Please enter a valid 10-digit phone number.")
        return
    contacts[name] = f"{intl_code}-{contact}"
    print("Contact added successfully.")

def show_region():
    name = input("Enter the name of the contact to find the region: ")
    if name in contacts:
        intl_code = contacts[name].split("-")[0].strip()  
        region = inter_code.get(intl_code, "Unknown Region.")
        print(f"The contact {name} is from {region}")
        if region!= inter_code.get(intl_code):
            print("This is still under process and can does not have all International Code.\nUpcoming updates will improve the experience very soon...")

    else:
        print(f"{name} not found.")

def search_contact():
    name = input("Enter the name of contact you want to search for : ")
    if (name) in contacts:
        print(f"{name}:{contacts[name]}")
    else:
        print(f"{name} not found.")

def delete_contact():
    name = input("Enter the name of the contact you want to delete : ")
    if name in contacts:
        del contacts[name]
        print(f"Contact of {name} deleted.")
    else:
        print("Contact not found.")
    
def display_contacts():
    if len(contacts)==0:
        print("No contacts added.")
    else:
        print(f"""--------CONTACT BOOK---------""")
        for name,contact in contacts.items():
            print(f"{name} : {contact}")

def menu():
    print(f"""-----Menu-----
Choose any one out of the following options(enter numbers only):
1.Add Contact
2.Delete Contact
3.Search Contact
4.Display All Contacts
5.Region of Contact
6.Exit""")
    return int(input("Enter your choice(numbers only) : "))


while True:
    try:
        operation = menu()
        if operation not in range (1,7):
            print("Invalid Input.")
        elif operation ==1:
            add_contact()
        elif operation ==2:
            delete_contact()
        elif operation==3:
            search_contact()
        elif operation==4:
            display_contacts()
        elif operation == 5:
            show_region()
        elif operation==6:
            print("THANK YOU")
            break   
    except ValueError:
        print("Please enter numbers only.")
