import time

# Programme to make a simple calculator
while True:
    print("Hello WELCOME!! to Simple Calculator")
    # taking user's information
    print("-----Log In-----")
    num_1 = str(input("Enter Your Name:\t"))
    num_2 = int(input("Enter Your Age:\t"))
    print(num_1, "Have Logged In Succussfully in Simple Calculator")
    # checking user's age criteria
    if num_2 >= 13:
        while True:
            print(" 1 = ADD\n 2 = Subtract\n 3 = Multiply\n 4 = Divide")
            input_1 = int(input("Enter 1/2/3/4(any one value):\t"))
            if input_1 not in range(1,5):
                print("Invalid Input!!")
                
            else:
                no_1 = float(input("Enter Your First Number:\t"))
                no_2 = float(input("Enter Your Second Number:\t"))
            # Asking the user for which operation to perform
                if input_1 == 1:
                    n_1 = no_1 + no_2
                    print(no_1, "+", no_2, "=", n_1)
                elif input_1 == 2:
                    n_2 = no_1 - no_2
                    print(no_1, "-", no_2, "=", n_2)
                elif input_1 == 3:
                    n_3 = no_1 * no_2
                    print(no_1, "x", no_2, "=", n_3)
                elif input_1 == 4:
                    if no_2 == 0:
                        print("Error!!! Cannot Divide By Zero.")
                    else:
                        n_4 = no_1 / no_2
                        print(no_1, "/", no_2, "=", n_4)
                else:
                    print("Invalid Input Try Again")

            run_again = input("Do you want to run the calculator again? (y/n):\t").lower()
            if run_again not in ("y"):
                print("Bye!!")
                time.sleep(2)
                raise SystemExit
    else:
        print("SORRY!!! You Cannot Use Simple Calculator... ")

    run_again = input("Do you want to run the calculator again? (y/n):\t").lower()
    if run_again not in ("y"):
        print("Bye!!")
        time.sleep(2)
        break