import customtkinter as ctk
from tkinter import messagebox
import math

# ---------------- CONFIG ---------------- #

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

history = []
expression = ""
incognito = False
history_window = None
is_dark_mode = True  

# ---------------- CENTER WINDOW ---------------- #

def center_window(win, w, h):
    screen_w = win.winfo_screenwidth()
    screen_h = win.winfo_screenheight()

    x = (screen_w // 2) - (w // 2)
    y = (screen_h // 2) - (h // 2)

    win.geometry(f"{w}x{h}+{x}+{y}")

# ---------------- KEYBOARD ENGINE ---------------- #

def handle_global_keypress(event):
    """
    Listens globally across the application and maps your laptop's keys 
    to duplicate native Windows Calculator behaviors along with custom Ctrl shortcuts.
    """
    global expression
    char = event.char
    key = event.keysym
    state = event.state

    # Check if Control key is being held down (handles Ctrl+H, Ctrl+I, Ctrl+T)
    # state & 0x0004 checks for the Ctrl modifier in Tkinter
    if state & 0x0004:
        if key.lower() == "h":
            toggle_history()
            return "break"
        elif key.lower() == "i":
            # Toggle the switch widget state programmatically and update
            if incognito_switch.get() == 0:
                incognito_switch.select()
            else:
                incognito_switch.deselect()
            toggle_incognito()
            return "break"
        elif key.lower() == "t":
            # Toggle the theme switch widget state programmatically and update
            if theme_switch.get() == 0:
                theme_switch.select()
            else:
                theme_switch.deselect()
            toggle_theme()
            return "break"

    # 1. Functional operational keys mapping
    if key == "Return" or char == "=":
        calculate()
        return "break"
    elif key == "BackSpace":
        backspace()
        return "break"
    elif key == "Escape":
        clear()
        return "break"

    # 2. Character symbol layout translation mappings
    operator_mapping = {
        "*": "×",
        "/": "÷"
    }
    if char in operator_mapping:
        update(operator_mapping[char])
        return "break"

    # 3. Whitelisted string characters (Numbers and base mathematical symbols)
    valid_chars = "0123456789.+-^"
    if char in valid_chars and char != "":
        update(char)
        return "break"

    # Blocks alphabet strings or unwanted random triggers from appending anything
    return "break"

# ---------------- CALC FUNCTIONS ---------------- #

def update(val):
    global expression
    expression += str(val)
    display.configure(state="normal")
    display.delete(0, "end")
    display.insert(0, expression)
    display.configure(state="readonly")

def clear():
    global expression
    expression = ""
    display.configure(state="normal")
    display.delete(0, "end")
    display.configure(state="readonly")

def backspace():
    global expression
    expression = expression[:-1]
    display.configure(state="normal")
    display.delete(0, "end")
    display.insert(0, expression)
    display.configure(state="readonly")

def calculate():
    global expression

    try:
        exp = expression.replace("×","*").replace("÷","/").replace("^","**")
        result = eval(exp)

        if not incognito:
            history.append(f"{expression} = {result}")

        expression = str(result)
        display.configure(state="normal")
        display.delete(0, "end")
        display.insert(0, expression)
        display.configure(state="readonly")

        update_history()

    except:
        messagebox.showerror("Error", "Invalid Expression")

def sqrt():
    global expression
    try:
        val = float(display.get())
        result = math.sqrt(val)

        if not incognito:
            history.append(f"√({val}) = {result}")

        expression = str(result)
        display.configure(state="normal")
        display.delete(0, "end")
        display.insert(0, expression)
        display.configure(state="readonly")

        update_history()

    except:
        messagebox.showerror("Error", "Invalid Input")

def toggle_incognito():
    global incognito

    if incognito_switch.get() == 1:
        incognito = True
        incognito_switch.configure(text="Incognito: ON")
    else:
        incognito = False
        incognito_switch.configure(text="Incognito: OFF")

def toggle_theme():
    global is_dark_mode
    if theme_switch.get() == 1:
        ctk.set_appearance_mode("Dark")
        is_dark_mode = True
        
        app.configure(fg_color="black")
        frame.configure(fg_color="black")
        display.configure(fg_color="#1a1a1a", text_color="white") 
        incognito_switch.configure(text_color="white")
    else:
        ctk.set_appearance_mode("Light")
        is_dark_mode = False
        
        app.configure(fg_color="white")
        frame.configure(fg_color="white")
        display.configure(fg_color="#f0f0f0", text_color="black") 
        incognito_switch.configure(text_color="black")

# ---------------- HISTORY ---------------- #

def clear_history():
    """Clears the internal history list and updates the display box."""
    global history
    history.clear()
    update_history()

def update_history():
    if history_window and history_window.winfo_exists():
        text_box.configure(state="normal")
        text_box.delete("1.0", "end")
        for item in history:
            text_box.insert("end", item + "\n")
        text_box.configure(state="disabled")

def toggle_history():
    global history_window

    if history_window and history_window.winfo_exists():
        history_window.destroy()
        history_window = None
        return

    history_window = ctk.CTkToplevel(app)
    history_window.title("History")
    history_window.geometry("350x350")  

    history_window.transient(app)
    history_window.lift()
    history_window.focus_force()
    history_window.grab_set()

    center_window(history_window, 350, 350)

    global text_box
    text_box = ctk.CTkTextbox(history_window)
    text_box.pack(fill="both", expand=True, padx=10, pady=(10, 5))

    text_box.bind("<Button-1>", lambda e: "break")
    text_box.bind("<FocusIn>", lambda e: history_window.focus_set())

    clear_btn = ctk.CTkButton(
        history_window, 
        text="Clear History", 
        fg_color="#d9534f",      
        hover_color="#c9302c", 
        command=clear_history
    )
    clear_btn.pack(fill="x", padx=10, pady=(5, 10))

    if is_dark_mode:
        history_window.configure(fg_color="black")
        text_box.configure(fg_color="#1a1a1a", text_color="white")
    else:
        history_window.configure(fg_color="white")
        text_box.configure(fg_color="#f0f0f0", text_color="black")

    update_history()

# ---------------- MAIN WINDOW ---------------- #

app = ctk.CTk()
app.title("Simple Calculator v1.1")
center_window(app, 900, 650)

app.configure(fg_color="black")

# TOP BAR
top = ctk.CTkFrame(app, fg_color="transparent") 
top.pack(fill="x", padx=10, pady=10)

history_btn = ctk.CTkButton(top, text="☰", width=40, command=toggle_history)
history_btn.pack(side="right", padx=5)

theme_switch = ctk.CTkSwitch(top, text="Theme", command=toggle_theme, progress_color="#BBBBBB")
theme_switch.select() 
theme_switch.pack(side="right", padx=15)

# CALCULATOR FRAME
frame = ctk.CTkFrame(app, fg_color="black")
frame.pack(expand=True)

display = ctk.CTkEntry(
    frame, 
    width=300, 
    height=60, 
    font=("Arial", 28), 
    justify="right", 
    fg_color="#1a1a1a",
    state="readonly"
)
display.grid(row=0, column=0, columnspan=4, padx=10, pady=10, sticky="ew")

# Global Event Hook: Captures normal typing AND key combinations flawlessly
app.bind("<Key>", handle_global_keypress)

buttons = [
    ("C",1,0), ("⌫",1,1), ("√",1,2), ("÷",1,3),
    ("7",2,0), ("8",2,1), ("9",2,2), ("×",2,3),
    ("4",3,0), ("5",3,1), ("6",3,2), ("-",3,3),
    ("1",4,0), ("2",4,1), ("3",4,2), ("+",4,3),
    ("0",5,0), (".",5,1), ("^",5,2), ("=",5,3)
]

for t,r,c in buttons:
    if t == "=":
        cmd = calculate
    elif t == "C":
        cmd = clear
    elif t == "⌫":
        cmd = backspace
    elif t == "√":
        cmd = sqrt
    else:
        cmd = lambda x=t: update(x)

    ctk.CTkButton(frame, text=t, command=cmd, height=60)\
        .grid(row=r, column=c, sticky="nsew", padx=3, pady=3)

for i in range(4):
    frame.grid_columnconfigure(i, weight=1)

# BOTTOM RIGHT CONTAINER FRAME
bottom_right_frame = ctk.CTkFrame(app, fg_color="transparent")
bottom_right_frame.pack(side="bottom", anchor="se", padx=15, pady=15)

incognito_switch = ctk.CTkSwitch(
    bottom_right_frame, 
    text="Incognito: OFF", 
    command=toggle_incognito,
    font=("Arial", 16),
    progress_color="#d9534f"  
)
incognito_switch.pack()

app.mainloop()