#Day 14 July
#Clock - 1.Displays time    2.Display date      3.Stopwatch     4.Timer 
#No ChatGPT
import time

def show_time():
    try:
        opt = int(input(f"""Do you want time in-
                        1. 24 hour format
                        2. 12 hour format 
                        Choice : """))
        if opt ==1:
            print(f"""Time: {time.strftime("%H:%M:%S %p")}""")
        elif opt==2:
            print(f"""Time: {time.strftime("%I:%M:%S %p")}""")
        elif opt<2 or opt>1:
            print("Choose within the provided options.")
    except ValueError:
        print("Answer with digits only.") 

def show_date():
    print(f"""Date: {time.strftime("%A, %B %d, %Y")}""")

def stopwatch():
    start = input("Press Enter to start the stopwatch")
    if start == "":
        t1 = time.time()
    else:
        print("Invalid key pressed.")
    
    stop = input("Press Enter to stop the stopwatch")
    if stop == "":
        t2 = time.time()
    else:
        print("Invalid input.")
    
    elapsed = int(t2 - t1)

    hours = elapsed//3600
    minutes = (elapsed%3600)//60
    seconds = elapsed%60

    print("\n====== RESULT ======")
    print(f"Elapsed Time: {hours:02}:{minutes:02}:{seconds:02}")

def timer():
    try:
        i = int(input("Enter the time(in seconds) for your timer :"))
        for n in range(i,0,-1):
            print(f"""{n}....""")
            time.sleep(1)
        print("Time's Up...")
    except ValueError:
        print("Enter time in digits only.")

def menu():
    print("\n" + "=" * 40)
    print("        ⏰ CLOCK INTERFACE")
    print("=" * 40)
    print("1. Show Current Time")
    print("2. Show Current Date")
    print("3. Stopwatch")
    print("4. Timer")
    print("5. Exit")
    print("=" * 40)

    try:
        option = int(input("Enter your choice (1-5): "))
        return option
    except ValueError:
        print("Please enter a valid number.")
        return 0
    
print("Welcome to the clock interface...")
while True:
    opt = menu()
    if opt not in range(1,6):
        print("Invalid input. Please check if you enterred the number for operation correctly.")
        continue
    
    if opt==5:
        print("Clock closed")
        print("Thank You")
        break
    
    if opt==1:
        show_time()
    elif opt==2:
        show_date()
    elif opt==3:
        stopwatch()
    elif opt==4:
        timer()
    else:
        print("Invalid input")