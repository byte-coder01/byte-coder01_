import os
import struct
import customtkinter as ctk
from tkinter import filedialog, messagebox
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes

# =====================================================================
# CRYPTO CONSTANTS & CORE CONFIGURATION
# =====================================================================
MAGIC = b"SFv1"         # Unique 4-byte file header identifier to prevent reading invalid formats
VERSION = 1            # File protocol version versioning for backwards compatibility
SALT_SIZE = 16         # 128-bit salt for Key Derivation Function (KDF) unique to each file
KEY_SIZE = 32          # 256-bit AES key size
ITERATIONS = 200000    # Work factor for PBKDF2 to slow down brute-force attacks
CHUNK_SIZE = 64 * 1024 # 64 KB memory chunks for performance balance

def derive_key(password: bytes, salt: bytes) -> bytes:
    """
    Transforms a text password into a cryptographically strong 256-bit key.
    Using PBKDF2 with SHA-256 prevents rainbow table and basic brute-force attacks.
    """
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=KEY_SIZE,
        salt=salt,
        iterations=ITERATIONS
    )
    return kdf.derive(password)

def get_chunk_nonce(base_nonce: bytes, chunk_index: int) -> bytes:
    """
    Generates a unique 12-byte initialization vector (nonce) for each chunk.
    Combines 8 random bytes with a sequentially incremented 4-byte counter.
    CRITICAL: Never reuse a nonce with the same key in AES-GCM mode.
    """
    return base_nonce[:8] + struct.pack(">I", chunk_index)

# =====================================================================
# CORE CRYPTOGRAPHIC PIPELINES
# =====================================================================
def encrypt_file(input_path, output_path, password):
    """
    Reads plaintext in chunks, encrypts each block securely via authenticated 
    AES-GCM, and streams the structure directly out to disk.
    """
    # Generate globally unique, random elements for this specific encryption run
    salt = os.urandom(SALT_SIZE)
    base_nonce = os.urandom(8) # The base randomness for chunk nonces
    
    # Calculate the key and initialize the Authenticated Encryption layout
    key = derive_key(password.encode(), salt)
    aesgcm = AESGCM(key)

    with open(input_path, "rb") as f_in, open(output_path, "wb") as f_out:
        # Step 1: Write static metadata header to the destination file
        f_out.write(MAGIC + struct.pack("B", VERSION) + salt + base_nonce)
        
        chunk_index = 0
        while True:
            # Step 2: Read raw file data incrementally
            chunk = f_in.read(CHUNK_SIZE)
            if not chunk: 
                break # Reached End-Of-File (EOF) safely
                
            # Step 3: Derive a brand new nonce for this block and encrypt
            nonce = get_chunk_nonce(base_nonce, chunk_index)
            ciphertext = aesgcm.encrypt(nonce, chunk, None)
            
            # Step 4: Write length indicator block (4 bytes) followed by payload + tag
            f_out.write(struct.pack(">I", len(ciphertext)) + ciphertext)
            chunk_index += 1
        
        # Step 5: Flush underlying write cache buffers to storage disk safely
        f_out.flush()
        os.fsync(f_out.fileno())

def decrypt_file(input_path, output_path, password):
    """
    ATOMIC DECRYPTION ENGINE: Reads and verifies every encrypted packet into a volatile 
    RAM array. If any packet fails integrity validation (tampering), memory is 
    destroyed immediately and NO modifications ever touch the hard drive.
    """
    # Temporary staging array located entirely inside RAM memory
    decrypted_buffer = bytearray()

    with open(input_path, "rb") as f_in:
        # Step 1: Read and validate the magic metadata header
        magic = f_in.read(4)
        if magic != MAGIC: 
            raise ValueError("NOT_A_SECUREFILE")
            
        version_bytes = f_in.read(1)
        if not version_bytes: 
            raise ValueError("CORRUPTED_HEADER")
        version = struct.unpack("B", version_bytes)[0]
        if version != VERSION: 
            raise ValueError("UNSUPPORTED_VERSION")
        
        # Step 2: Extract key generation values and baseline nonce parameters
        salt = f_in.read(SALT_SIZE)
        base_nonce = f_in.read(8)
        if len(salt) < SALT_SIZE or len(base_nonce) < 8:
            raise ValueError("CORRUPTED_HEADER")

        # Step 3: Recompute original encryption key using stored salt parameters
        key = derive_key(password.encode(), salt)
        aesgcm = AESGCM(key)

        chunk_index = 0
        while True:
            # Step 4: Read length prefix byte marker for the incoming block
            length_bytes = f_in.read(4)
            if not length_bytes: 
                break # Complete data array navigated safely
                
            chunk_len = struct.unpack(">I", length_bytes)[0]
            ciphertext = f_in.read(chunk_len)
            if len(ciphertext) != chunk_len:
                raise ValueError("TRUNCATED_FILE")

            # Step 5: Regenerate chunk counter nonce to check this package block
            nonce = get_chunk_nonce(base_nonce, chunk_index)
            try:
                # Attempt to authenticate cryptographic integrity tags and decrypt data
                plaintext = aesgcm.decrypt(nonce, ciphertext, None)
                decrypted_buffer.extend(plaintext) # Save into RAM temporary pool
            except Exception:
                # TAMPER PROTECTION PROTOCOL: If authentication fails, purge the 
                # sensitive memory pool instantly and exit execution before writing to disk.
                del decrypted_buffer
                raise ValueError("BAD_PASSWORD_OR_TAMPERED")
                
            chunk_index += 1

    # Step 6: File verified 100% authentic. Commit completely to the storage disk.
    with open(output_path, "wb") as f_out:
        f_out.write(decrypted_buffer)
        f_out.flush()
        os.fsync(f_out.fileno())

# =====================================================================
# GRAPHICAL USER INTERFACE MANAGEMENT (CustomTkinter)
# =====================================================================
ctk.set_appearance_mode("System")  # Sync dark or light setting to Operating System parameters
ctk.set_default_color_theme("blue")

class SecureFileCustomGUI(ctk.CTk):
    def __init__(self):
        super().__init__()
        
        # Configure Main Window Properties
        self.title("SecureFile AES-GCM Vault")
        self.geometry("540x260")
        self.resizable(False, False)
        
        # Setup Component Bound Application Variables
        self.file_path = ctk.StringVar()
        self.password = ctk.StringVar()

        # Visual Row 1: File Search & Browser
        self.lbl_file = ctk.CTkLabel(self, text="Select File:", font=("Helvetica", 13, "bold"))
        self.lbl_file.grid(row=0, column=0, padx=20, pady=(25, 10), sticky="w")
        
        self.file_entry = ctk.CTkEntry(self, textvariable=self.file_path, width=280, placeholder_text="Path to file...")
        self.file_entry.grid(row=0, column=1, padx=5, pady=(25, 10))
        
        self.btn_browse = ctk.CTkButton(self, text="Browse", width=80, command=self.browse_file)
        self.btn_browse.grid(row=0, column=2, padx=20, pady=(25, 10))

        # Visual Row 2: Secure Password Configuration Field
        self.lbl_pass = ctk.CTkLabel(self, text="Password:", font=("Helvetica", 13, "bold"))
        self.lbl_pass.grid(row=1, column=0, padx=20, pady=15, sticky="w")
        
        self.pass_entry = ctk.CTkEntry(self, textvariable=self.password, show="*", width=280, placeholder_text="Enter encryption key...")
        self.pass_entry.grid(row=1, column=1, padx=5, pady=15, columnspan=2, sticky="w")

        # Visual Row 3: Action Buttons Framing Anchor Layout
        self.btn_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.btn_frame.grid(row=2, column=0, columnspan=3, pady=(25, 10), sticky="nsew")
        self.btn_frame.grid_columnconfigure((0, 1), weight=1)

        # Trigger Actions Setup Mapping
        self.enc_btn = ctk.CTkButton(self.btn_frame, text="🔒 Encrypt File", fg_color="#1f538d", hover_color="#14375e", height=40, command=lambda: self.process_file("encrypt"))
        self.enc_btn.grid(row=0, column=0, padx=20, sticky="e")

        self.dec_btn = ctk.CTkButton(self.btn_frame, text="🔓 Decrypt File", fg_color="#228b22", hover_color="#176117", height=40, command=lambda: self.process_file("decrypt"))
        self.dec_btn.grid(row=0, column=1, padx=20, sticky="w")

    def browse_file(self):
        """ Opens native operating system dialog window to grab a target file path string """
        filename = filedialog.askopenfilename(title="Select a file to process")
        if filename:
            self.file_path.set(filename)

    def process_file(self, action):
        """ Handles field data, errors, target locations, and input wiping mechanisms """
        in_path = self.file_path.get()
        pwd = self.password.get()

        # Input Parameter Validation Checkpoints
        if not in_path or not os.path.exists(in_path):
            messagebox.showerror("Error", "Please select a valid input file.")
            self.file_path.set("") 
            self.password.set("")
            return
        if not pwd:
            messagebox.showerror("Error", "Please enter a password.")
            return

        try:
            if action == "encrypt":
                # Prompt user for save destination, proposing a .enc extension suffix template
                out_path = filedialog.asksaveasfilename(title="Save Encrypted File As", initialfile="Encrypted_" + os.path.basename(in_path) + ".enc")
                
                if out_path: # Executes block only if a destination was chosen (Skips if user clicks Cancel)
                    if os.path.exists(out_path):
                        try: os.remove(out_path)
                        except Exception: pass

                    try:
                        encrypt_file(in_path, out_path, pwd)
                        messagebox.showinfo("Success", "File encrypted securely!")
                    except PermissionError:
                        messagebox.showerror("Error", "Permission Denied!\n\nPlease close the file in Excel before trying to encrypt it.")
                    except Exception as e:
                        messagebox.showerror("Error", f"Encryption failed:\n{str(e)}")

            elif action == "decrypt":
                # Strip out target file extensions to suggest a human-readable destination layout name
                default_name = os.path.basename(in_path).replace(".enc", "")
                out_path = filedialog.asksaveasfilename(title="Save Decrypted File As", initialfile="Restored_" + default_name)
                
                if out_path: # Executes block only if a destination was chosen (Skips if user clicks Cancel)
                    if os.path.exists(out_path):
                        try: os.remove(out_path)
                        except Exception: pass

                    try:
                        decrypt_file(in_path, out_path, pwd)
                        messagebox.showinfo("Success", "File decrypted successfully!")
                    except Exception as e:
                        # Translate internal pipeline crashes into friendly diagnostic errors
                        err_msg = str(e)
                        if "NOT_A_SECUREFILE" in err_msg:
                            msg = "This file was not created by this application."
                        elif "UNSUPPORTED_VERSION" in err_msg:
                            msg = "This file was encrypted with an older, incompatible version of this tool."
                        elif "TRUNCATED_FILE" in err_msg:
                            msg = "The encrypted file is incomplete or has been corrupted."
                        elif "BAD_PASSWORD_OR_TAMPERED" in err_msg:
                            msg = "Decryption failed.\n\nPossible reasons:\n1. Incorrect password.\n2. The file has been corrupted or altered."
                        else:
                            msg = f"Unexpected Error: {err_msg}"
                        
                        messagebox.showerror("Decryption Failed", msg)
                        if os.path.exists(out_path):
                            os.remove(out_path)
        
        finally:
            # FORCE WIPE GUARANTEE: This segment executes automatically at termination.
            # Clears internal state parameters on successful processing, error traps, or cancellations.
            self.file_path.set("")   
            self.password.set("")    

if __name__ == "__main__":
    app = SecureFileCustomGUI()
    app.mainloop()