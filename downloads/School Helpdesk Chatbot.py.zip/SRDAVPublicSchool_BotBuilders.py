import random
import pickle
import difflib
import tkinter as tk

import nltk
import customtkinter as ctk

from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
from nltk.classify import NaiveBayesClassifier
from nltk.probability import FreqDist
from nltk.corpus import stopwords

# =========================================================
# DOWNLOAD NLTK DATA
# =========================================================
nltk.download("punkt")
nltk.download("punkt_tab")  # FIXED LOOKUP ERROR
nltk.download("wordnet")
nltk.download("omw-1.4")
nltk.download("stopwords")

# =========================================================
# APP THEME
# =========================================================
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

# =========================================================
# COLORS
# =========================================================
USER_BUBBLE = "#2563eb"
BOT_BUBBLE = "#2d2d2d"

# =========================================================
# NLP SETUP
# =========================================================
lemmatizer = WordNetLemmatizer()
stop_words = set(stopwords.words("english"))

# =========================================================
# MEMORY
# =========================================================
last_intent = None
chat_history = []

# =========================================================
# INTENTS
# =========================================================
intents = [

# =========================================================
# GREETING
# =========================================================
{
    "tag": "greeting",

    "patterns": [
        "hello", "hi", "hey",
        "good morning", "good evening",
        "good afternoon", "yo",
        "is anyone there",
        "hello bot",
        "hi assistant",
        "namaste"
    ],

    "responses": [
        "Hello! How can I assist you today?",
        "Hi! Welcome to the School Helpdesk Assistant.",
        "Hey! How may I help you?"
    ]
},

# =========================================================
# GOODBYE
# =========================================================
{
    "tag": "goodbye",

    "patterns": [
        "bye", "goodbye",
        "see you later",
        "bye bye",
        "exit",
        "quit"
    ],

    "responses": [
        "Goodbye! Have a wonderful day.",
        "See you later!",
        "Take care!"
    ]
},

# =========================================================
# THANKS
# =========================================================
{
    "tag": "thanks",

    "patterns": [
        "thanks",
        "thank you",
        "thank you so much",
        "thx",
        "thanks a lot"
    ],

    "responses": [
        "You're welcome!",
        "Happy to help!",
        "Anytime!"
    ]
},

# =========================================================
# SCHOOL TIMINGS
# =========================================================
{
    "tag": "timings",

    "patterns": [
        "bell timings",
        "school timing",
        "when does school start",
        "when does school end",
        "school hours",
        "daily schedule",
        "school bell timings"
    ],

    "responses": [

        """SCHOOL TIMINGS

8:00 AM - 8:15 AM → Morning Assembly
8:15 AM - 8:55 AM → Period 1
8:55 AM - 9:35 AM → Period 2
9:35 AM - 10:15 AM → Period 3
10:15 AM - 10:30 AM → Short Break
10:30 AM - 11:10 AM → Period 4
11:10 AM - 11:50 AM → Period 5
11:50 AM - 12:25 PM → Lunch Break
12:25 PM - 1:05 PM → Period 6
1:05 PM - 1:45 PM → Period 7
1:45 PM - 2:00 PM → Pack-up

School runs from 8:00 AM to 2:00 PM."""
    ]
},

# =========================================================
# FEES
# =========================================================
{
    "tag": "fees",

    "patterns": [
        "school fees",
        "fee structure",
        "fees details",
        "how much is fee",
        "annual fees",
        "monthly fees",
        "fees information"
    ],

    "responses": [
        "Please contact the school office for complete fee details.",
        "Fee structure is available at the accounts office."
    ]
},

# =========================================================
# ADMISSION
# =========================================================
{
    "tag": "admission",

    "patterns": [
        "admission process",
        "how to take admission",
        "admission details",
        "is admission open",
        "how to apply",
        "admission form",
        "new admission"
    ],

    "responses": [
        "Admissions are open till 25th May 2026.",
        "Please visit the school office for admission process and forms."
    ]
},

# =========================================================
# EXAMS
# =========================================================
{
    "tag": "exams",

    "patterns": [
        "exam dates",
        "exam schedule",
        "when are exams",
        "exam timetable",
        "test schedule",
        "school exams",
        "upcoming exams",
        "exam"
    ],

    "responses": [
        "Exams are from 14th May to 22nd May 2026.",
        "Please check the notice board for complete exam schedule."
    ]
},

# =========================================================
# UNIFORM
# =========================================================
{
    "tag": "uniform",

    "patterns": [
        "school uniform",
        "where to buy uniform",
        "dress code",
        "winter uniform",
        "sports uniform days",
        "house uniform colors"
    ],

    "responses": [
        "The school uniform can be purchased from our authorized campus store or official city vendors."
    ]
},

# =========================================================
# RESULTS
# =========================================================
{
    "tag": "results",

    "patterns": [
        "result date",
        "exam result",
        "report card",
        "marksheet",
        "when will results come",
        "result declaration"
    ],

    "responses": [
        "Results will be declared soon.",
        "Please check the school portal for result updates."
    ]
},

# =========================================================
# HOLIDAYS
# =========================================================
{
    "tag": "holidays",

    "patterns": [
        "holiday list",
        "school holidays",
        "is school closed tomorrow",
        "when are holidays starting",
        "when will school holidays start",  # FIXED COMMA
        "holiday calendar",
        "next holiday",
        "school holiday information",
        "holiday information of the institute"
    ],

    "responses": [
        "Holiday list is available in the school almanac.",
        "Please check the school calendar for holidays."
    ]
},

# =========================================================
# TRANSPORT
# =========================================================
{
    "tag": "transport",

    "patterns": [
        "school bus",
        "transport facility",
        "bus route",
        "bus timing",
        "transport details"
    ],

    "responses": [
        "School transport facility is available.",
        "Please contact the transport office for bus routes and timings."
    ]
},

# =========================================================
# FACILITIES
# =========================================================
{
    "tag": "facilities",

    "patterns": [
        "school facilities",
        "library available",
        "computer lab",
        "science labs",
        "sports facilities"
    ],

    "responses": [
        "Our school has smart classrooms, library, science labs, computer labs, and sports facilities."
    ]
},

# =========================================================
# CONTACT
# =========================================================
{
    "tag": "contact",

    "patterns": [
        "contact details",
        "phone number",
        "school contact",
        "email address",
        "contact info",
        "email"
    ],

    "responses": [

        """📞 CONTACT DETAILS

Phone No.: 011-47070367
School Gate No.: 011-40450501
E-Mail: davr_dv@yahoo.com
Website: davdayanandvihar.net"""
    ]
},

# =========================================================
# LOCATION
# =========================================================
{
    "tag": "location",

    "patterns": [
        "school address",
        "where is school",
        "location of school",
        "how to reach school",
        "where are you located"
    ],

    "responses": [

        """📍 SCHOOL ADDRESS

SHAHEED RAJPAL DAV PUBLIC SCHOOL
Arya Nagar, Dayanand Vihar,
Anand Vihar,
Delhi - 110092,
India"""
    ]
},

# =========================================================
# FALLBACK
# =========================================================
{
    "tag": "fallback",

    "patterns": [],

    "responses": [
        "Sorry, I couldn't understand that.",
        "Could you rephrase your question?"
    ]
}

]

# =========================================================
# PREPROCESSING
# =========================================================
def preprocess(sentence):

    tokens = word_tokenize(sentence.lower())

    cleaned_words = []

    for word in tokens:

        if word.isalnum():

            if word not in stop_words:

                word = lemmatizer.lemmatize(word)

                cleaned_words.append(word)

    return cleaned_words


# =========================================================
# PREPARE TRAINING DATA
# =========================================================
def prepare_training_data(intents):

    data = []

    for intent in intents:
        for pattern in intent["patterns"]:
            data.append((pattern, intent["tag"]))

    return data


# =========================================================
# BUILD VOCAB
# =========================================================
def build_vocab(data):

    words = []

    for text, _ in data:
        words.extend(preprocess(text))

    return list(FreqDist(words).keys())


# =========================================================
# FEATURE EXTRACTION
# =========================================================
def extract_features(sentence, vocab):

    words = preprocess(sentence)

    return {
        word: words.count(word)
        for word in vocab
    }


# =========================================================
# TRAIN MODEL
# =========================================================
def train_model(data):

    vocab = build_vocab(data)

    training_set = [

        (extract_features(text, vocab), label)

        for text, label in data
    ]

    classifier = NaiveBayesClassifier.train(training_set)

    with open("model.pkl", "wb") as f:
        pickle.dump((classifier, vocab), f)

    return classifier, vocab


# =========================================================
# LOAD MODEL
# =========================================================
def load_model():

    with open("model.pkl", "rb") as f:

        classifier, vocab = pickle.load(f)

    return classifier, vocab


# =========================================================
# GET RESPONSE
# =========================================================
def get_response(tag):

    for intent in intents:

        if intent["tag"] == tag:

            return random.choice(intent["responses"])

    return "I don't understand."


# =========================================================
# FUZZY MATCHING
# =========================================================
def fuzzy_match(user_message):

    all_patterns = []

    for intent in intents:

        for pattern in intent["patterns"]:

            all_patterns.append((pattern, intent["tag"]))

    matches = difflib.get_close_matches(
        user_message.lower(),
        [p[0] for p in all_patterns],
        n=1,
        cutoff=0.75
    )

    if matches:

        matched_pattern = matches[0]

        for pattern, tag in all_patterns:

            if pattern == matched_pattern:

                return tag

    return None


# =========================================================
# LOAD OR TRAIN MODEL
# =========================================================
data = prepare_training_data(intents)

try:

    classifier, vocab = load_model()

except:

    classifier, vocab = train_model(data)


# =========================================================
# MAIN WINDOW
# =========================================================
root = ctk.CTk()

root.geometry("1000x700")

root.title("School Helpdesk")


# =========================================================
# SIDEBAR
# =========================================================
sidebar = ctk.CTkFrame(
    root,
    width=200,
    corner_radius=0
)

sidebar.pack(side="left", fill="y")


# =========================================================
# LOGO
# =========================================================
logo = ctk.CTkLabel(
    sidebar,
    text="  School AI",
    font=("Segoe UI", 28, "bold")
)

logo.pack(pady=30)


# =========================================================
# MAIN FRAME
# =========================================================
main_frame = ctk.CTkFrame(root)

main_frame.pack(
    side="right",
    fill="both",
    expand=True
)


# =========================================================
# HEADER
# =========================================================
header = ctk.CTkLabel(
    main_frame,
    text="School Helpdesk Assistant",
    font=("Segoe UI", 30, "bold")
)

header.pack(pady=20)


# =========================================================
# CHAT FRAME
# =========================================================
chat_frame = ctk.CTkScrollableFrame(
    main_frame,
    corner_radius=15
)

chat_frame.pack(
    padx=20,
    pady=10,
    fill="both",
    expand=True
)


# =========================================================
# INPUT FRAME
# =========================================================
input_frame = ctk.CTkFrame(main_frame)

input_frame.pack(
    side="bottom",
    fill="x",
    padx=20,
    pady=20
)


# =========================================================
# INPUT BOX
# =========================================================
user_input = ctk.CTkEntry(
    input_frame,
    placeholder_text="Type your message here...",
    height=45,
    corner_radius=20,
    font=("Segoe UI", 15)
)

user_input.pack(
    side="left",
    fill="x",
    expand=True,
    padx=(10, 10),
    pady=10
)


# =========================================================
# ADD MESSAGE
# =========================================================
def add_message(message, sender="bot"):

    bubble_frame = ctk.CTkFrame(
        chat_frame,
        fg_color="transparent"
    )

    bubble_frame.pack(
        fill="x",
        pady=5,
        padx=10
    )

    bubble_color = USER_BUBBLE if sender == "user" else BOT_BUBBLE
    anchor = "e" if sender == "user" else "w"

    bubble = ctk.CTkLabel(
        bubble_frame,
        text=message,
        font=("Segoe UI", 14),
        fg_color=bubble_color,
        text_color="white",
        corner_radius=20,
        padx=15,
        pady=10,
        wraplength=600,
        justify="left"
    )

    bubble.pack(anchor=anchor, padx=10)

    chat_frame._parent_canvas.yview_moveto(1.0)


# =========================================================
# CLEAR CHAT
# =========================================================
def clear_chat():

    for widget in chat_frame.winfo_children():

        widget.destroy()

    add_message(
        "Welcome to School Helpdesk Assistant!",
        "bot"
    )


# =========================================================
# CLEAR BUTTON
# =========================================================
clear_button = ctk.CTkButton(
    sidebar,
    text=" New Chat",
    corner_radius=15,
    command=clear_chat
)

clear_button.pack(pady=20)


# =========================================================
# GENERATE RESPONSE
# =========================================================
def generate_response(message):

    global last_intent

    lower_message = message.lower()

    # EXACT MATCH
    for intent in intents:

        for pattern in intent["patterns"]:

            if lower_message == pattern.lower():

                last_intent = intent["tag"]

                return random.choice(intent["responses"])

    # FUZZY MATCHING
    fuzzy_intent = fuzzy_match(lower_message)

    if fuzzy_intent:

        last_intent = fuzzy_intent

        return get_response(fuzzy_intent)

    # AI CLASSIFIER
    features = extract_features(message, vocab)

    prob_dist = classifier.prob_classify(features)

    intent = prob_dist.max()

    confidence = prob_dist.prob(intent)

    print("Intent:", intent)
    print("Confidence:", confidence)

    if confidence > 0.65:

        last_intent = intent

        return get_response(intent)

    # CONTEXT MEMORY
    if (
        last_intent == "admission"
        and "fees" in lower_message
    ):

        return (
            "Admission fee details are available "
            "at the school office."
        )

    # FALLBACK
    return (
        "I couldn't understand your question properly.\n"
        "Please rephrase it."
    )


# =========================================================
# SEND MESSAGE
# =========================================================
def send_message():

    message = user_input.get().strip()

    if message == "":
        return

    add_message(message, "user")

    user_input.delete(0, tk.END)

    typing_label = ctk.CTkLabel(
        chat_frame,
        text="Bot is typing...",
        font=("Segoe UI", 12),
        text_color="gray"
    )

    typing_label.pack(
        anchor="w",
        padx=20,
        pady=5
    )

    def show_response():

        typing_label.destroy()

        response = generate_response(message)

        add_message(response, "bot")

    typing_time = random.randint(700, 1500)

    root.after(typing_time, show_response)


# =========================================================
# SEND BUTTON
# =========================================================
send_button = ctk.CTkButton(
    input_frame,
    text="Send",
    width=120,
    height=45,
    corner_radius=20,
    font=("Segoe UI", 15, "bold"),
    command=send_message
)

send_button.pack(
    side="right",
    padx=(0, 10),
    pady=10
)


# =========================================================
# ENTER KEY SUPPORT
# =========================================================
root.bind(
    "<Return>",
    lambda event: send_message()
)


# =========================================================
# INITIAL MESSAGE
# =========================================================
add_message(
    "Welcome to the School Helpdesk Assistant!",
    "bot"
)


# =========================================================
# START APP
# =========================================================
root.mainloop()