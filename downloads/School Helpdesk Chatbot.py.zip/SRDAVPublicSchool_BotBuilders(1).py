# =========================================================
# STANDARD LIBRARIES
# =========================================================
import random
import pickle
import tkinter as tk

# =========================================================
# THIRD PARTY LIBRARIES
# =========================================================
import nltk
import customtkinter as ctk

# =========================================================
# NLTK IMPORTS
# =========================================================
from nltk.stem import WordNetLemmatizer
from nltk.classify import NaiveBayesClassifier
from nltk.probability import FreqDist

# =========================================================
# DOWNLOAD NLTK DATA
# =========================================================
nltk.download("wordnet")
nltk.download("omw-1.4")

# =========================================================
# APP THEME
# =========================================================
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

# =========================================================
# COLORS
# =========================================================
USER_BUBBLE = "#2563eb"
BOT_BUBBLE = "#2d2d2d"

# =========================================================
# NLP SETUP
# =========================================================
lemmatizer = WordNetLemmatizer()

# =========================================================
# INTENTS
# =========================================================
intents = [

# -------------------------------
# GREETING 
# -------------------------------
{
    "tag": "greeting",
    "patterns": [
        "hello", "hi", "hey", "good morning", "good afternoon",
        "good evening", "is anyone there", "hello there",
        "hi bot", "hey bot", "yo", "hii", "helloo",
        "hey there", "hi there", "greetings",
        "anyone here", "are you there", "hi assistant",
        "hello assistant", "hey assistant"
    ],
    "responses": [
        "Hello! How can I assist you?",
        "Hi! Welcome to the school helpdesk."
    ]
},

# -------------------------------
# GOODBYE 
# -------------------------------
{
    "tag": "goodbye",
    "patterns": [
        "bye", "goodbye", "see you", "talk to you later",
        "see you later", "bye bye", "i am leaving",
        "ok bye", "bye for now", "catch you later",
        "see ya", "good night", "i have to go",
        "leaving now", "exit", "quit",
        "bye bot", "thanks bye", "see you soon", "later"
    ],
    "responses": [
        "Goodbye!", "Have a great day!"
    ]
},

# -------------------------------
# THANKS 
# -------------------------------
{
    "tag": "thanks",
    "patterns": [
        "thanks", "thank you", "thanks a lot",
        "ok thanks", "thx", "thank you so much",
        "thanks bot", "thanks a ton", "many thanks",
        "appreciate it", "thanks for help",
        "thanks buddy", "thank you very much",
        "thanks a lot bot", "great thanks",
        "ok thank you", "thanks again",
        "thank u", "ty", "thanks dear"
    ],
    "responses": [
        "You're welcome!", "Happy to help!"
    ]
},

# -------------------------------
# TIMINGS 
# -------------------------------
{
    "tag": "timings",
    "patterns": [
        "school timings", "what are school timings",
        "when does school start", "when does school end",
        "what time school starts", "what time school ends",
        "tell me school time", "school opening time",
        "school closing time", "timing of school",
        "when school opens", "when school closes",
        "what is school schedule", "daily timing of school",
        "school start time", "school end time",
        "school hours",
        "what is school timing today",
        "today school timing",
        "is school open today timing",
        "timing for school today",
    ],
    "responses": [
        "School runs from 8:00 AM to 2:00 PM."
    ]
},

# -------------------------------
# FEES 
# -------------------------------
{
    "tag": "fees",
    "patterns": [
        "what is the fee", "fee structure", "school fees",
        "how much is fee", "fees details",
        "tell me fees", "what are the fees",
        "fee of school", "monthly fees",
        "when to pay fees", "last date for fees",
        "fee payment date",
        "how to pay fees", "fee payment method",
        "is fees paid online",
        "fees receipt", "fees slip",
        "fees for class 10", "fees for class 9",
        "fees installment", "can i pay fees in parts",
        "late fee charge", "fine for late fee",
        "school fees amount", "total fees",
        "annual fees", "quarterly fees",
        "fees information", "fees enquiry"
    ],
    "responses": [
        "Please contact the office for detailed fee structure.",
        "Fee details are available at the school office."
    ]
},

# -------------------------------
# ADMISSION 
# -------------------------------
{
    "tag": "admission",
    "patterns": [
        "how to take admission", "admission process",
        "is admission open", "how can i join school",
        "admission details", "apply for admission",
        "how to apply", "admission form",
        "can i get admission", "joining process",
        "school admission details",
        "admission enquiry",
        "admission last date",
        "documents required for admission",
        "how to enroll",
        "enrollment process",
        "registration for school",
        "new admission process",
        "class 11 admission",
        "class 10 admission",
        "transfer admission",
        "admission eligibility",
        "who can apply admission",
        "admission fees"
    ],
    "responses": [
        "Admissions are open till 25th May,2026. Please visit the school office.",
        "You can apply through the admission desk till 25th May,2026."
    ]
},

# -------------------------------
# EXAMS 
# -------------------------------
{
    "tag": "exams",
    "patterns": [
        "when are exams", "exam schedule", "exam dates",
        "final exam date", "test schedule",
        "next exam date", "when is next exam",
        "exam time table", "exam timetable",
        "half yearly exam date",
        "annual exam date",
        "exam routine", "exam planning",
        "schedule of exams",
        "exam list",
        "exam calendar",
        "exam details",
        "mid term exam date",
        "term exam date",
        "upcoming exams"
    ],
    "responses": [
        "Exams are starting from 14th May,2026.",
        "Exams are from 14th - 22nd May 2026"
    ]
},

# -------------------------------
# RESULTS 
# -------------------------------
{
    "tag": "results",
    "patterns": [
        "when will results come", "result date",
        "check results", "how to see result",
        "exam results", "result announcement",
        "report card",
        "marksheet",
        "student result",
        "class result",
        "final result date",
        "result status",
        "result update"
    ],
    "responses": [
        "Results will be declared soon."
    ]
},

# -------------------------------
# HOLIDAYS 
# -------------------------------
{
    "tag": "holidays",
    "patterns": [
        "holiday list", "school holidays",
        "is school closed tomorrow",
        "when are holidays", "next holiday",
        "holiday schedule",
        "holiday calendar",
        "list of holidays",
        "holiday details",
        "school closed today",
        "holiday notice"
    ],
    "responses": [
        "List of Holidays are mentioned in the School Almanac "
    ]
},

# -------------------------------
# TRANSPORT 
# -------------------------------
{
    "tag": "transport",
    "patterns": [
        "school bus", "transport facility",
        "bus timing", "is bus available",
        "school transport details",
        "bus route", "transport details",
        "school bus facility",
        "bus service available",
        "school van", "transport service"
    ],
    "responses": [
        "School transport is available.",
        "Please contact transport office for details."
    ]
},

# -------------------------------
# FACILITIES 
# -------------------------------
{
    "tag": "facilities",
    "patterns": [
        "school facilities", "do you have library",
        "sports facilities", "computer lab",
        "what facilities are available",
        "labs in school", "library available",
        "facilities details",
        "infrastructure of school",
        "school resources"
    ],
    "responses": [
        "Our school has library, labs, and sports facilities."
    ]
},

# -------------------------------
# CONTACT 
# -------------------------------
{
    "tag": "contact",
    "patterns": [
        "contact",
        "contact info",
        "contact details",
        "school contact",
        "school contact number",
        "phone number",
        "school phone",
        "telephone number",
        "school telephone",
        "email of school",
        "school email",
        "email address",
        "how to contact school",
        "office number",
        "school office number",
        "school helpline",
        "call school",
        "principal contact",
        "contact school",
        "school mobile number",
        "school contact number", "phone number",
        "email of school", "how to contact school ?",
        "school phone", "contact details",
        "contact info"
    ],
    "responses": [
        "\nPhone No. : 011-47070367, 41619779\nSchool Gate No. : 011-40450501\nE-Mail : davr_dv@yahoo.com\nWebsite : davdayanandvihar.net"
    ]
},

# -------------------------------
# LOCATION 
# -------------------------------
{
    "tag": "location",
    "patterns": [
        "where is school", "school address",
        "location of school", "how to reach school",
        "school location",
        "map location",
        "school ka address",
    ],
    "responses": [
        "School address is - SHAHEED RAJPAL DAV PUBLIC SCHOOL, Arya Nagar, Dayanand Vihar, Anand Vihar, Delhi, 110092, India"
    ]
},

# -------------------------------
# FALLBACK
# -------------------------------
{
    "tag": "fallback",
    "patterns": [],
    "responses": [
        "Sorry, I didn't understand. Please try again.",
        "Can you rephrase your question?"
    ]
}

]
# =========================================================
# KNOWLEDGE BASE
# =========================================================
knowledge_base = {

    "who is the principal" or "what is the principal's name" or "Tell me principal's name":
        "Ms. Vanita Kapoor is the principal.",

    "school timing":
        "School starts at 8:00 AM and ends at 2:00 PM.",

    "where is the library":
        "The library is on the second floor.",

    "what is the school name":
        "Our school is SRDAV Public School."
}

# =========================================================
# PREPROCESSING
# =========================================================
def preprocess(sentence):

    return [

        lemmatizer.lemmatize(word)

        for word in sentence.lower().split()
    ]

# =========================================================
# PREPARE TRAINING DATA
# =========================================================
def prepare_training_data(intents):

    data = []

    for intent in intents:

        for pattern in intent["patterns"]:

            data.append((pattern, intent["tag"]))

    return data

# =========================================================
# BUILD VOCABULARY
# =========================================================
def build_vocab(data):

    words = []

    for text, _ in data:

        words.extend(preprocess(text))

    return list(FreqDist(words).keys())

# =========================================================
# FEATURE EXTRACTION
# =========================================================
def extract_features(sentence, vocab):

    words = preprocess(sentence)

    return {

        w: (w in words)

        for w in vocab
    }

# =========================================================
# TRAIN MODEL
# =========================================================
def train_model(data):

    vocab = build_vocab(data)

    training_set = [

        (extract_features(text, vocab), label)

        for text, label in data
    ]

    classifier = NaiveBayesClassifier.train(training_set)

    with open("model.pkl", "wb") as f:

        pickle.dump((classifier, vocab), f)

    return classifier, vocab

# =========================================================
# LOAD MODEL
# =========================================================
def load_model():

    with open("model.pkl", "rb") as f:

        classifier, vocab = pickle.load(f)

    return classifier, vocab

# =========================================================
# GET RESPONSE
# =========================================================
def get_response(tag):

    for intent in intents:

        if intent["tag"] == tag:

            return random.choice(intent["responses"])

    return "I don't understand."

# =========================================================
# LOAD OR TRAIN MODEL
# =========================================================
data = prepare_training_data(intents)

try:

    classifier, vocab = load_model()

except:

    classifier, vocab = train_model(data)

# =========================================================
# MAIN WINDOW
# =========================================================
root = ctk.CTk()

root.geometry("1000x650")

root.title("School Helpdesk")

# =========================================================
# SIDEBAR
# =========================================================
sidebar = ctk.CTkFrame(

    root,

    width=200,

    corner_radius=0
)

sidebar.pack(side="left", fill="y")

# =========================================================
# LOGO
# =========================================================
logo = ctk.CTkLabel(

    sidebar,

    text="  School Helpdesk",

    font=("Segoe UI", 28, "bold")
)

logo.pack(pady=30)

# =========================================================
# MAIN FRAME
# =========================================================
main_frame = ctk.CTkFrame(root)

main_frame.pack(
    side="right",
    fill="both",
    expand=True
)

# =========================================================
# HEADER
# =========================================================
header = ctk.CTkLabel(
    main_frame,
    text="School Helpdesk Assistant",
    font=("Segoe UI", 30, "bold")
)

header.pack(pady=20)

# =========================================================
# CHAT FRAME
# =========================================================
chat_frame = ctk.CTkScrollableFrame(
    main_frame,
    corner_radius=15
)

chat_frame.pack(
    padx=20,
    pady=10,
    fill="both",
    expand=True
)

# =========================================================
# INPUT FRAME
# =========================================================
input_frame = ctk.CTkFrame(main_frame)

input_frame.pack(
    side="bottom",
    fill="x",
    padx=20,
    pady=20
)

# =========================================================
# INPUT BOX
# =========================================================
user_input = ctk.CTkEntry(
    input_frame,
    placeholder_text="Type your message here...",
    height=45,
    corner_radius=20,
    font=("Segoe UI", 15)
)

user_input.pack(
    side="left",
    fill="x",
    expand=True,
    padx=(10, 10),
    pady=10
)

# =========================================================
# ADD MESSAGE
# =========================================================
def add_message(message, sender="bot"):

    bubble_frame = ctk.CTkFrame(

        chat_frame,

        fg_color="transparent"
    )

    bubble_frame.pack(

        fill="x",

        pady=5,

        padx=10
    )

    # USER MESSAGE
    if sender == "user":

        bubble = ctk.CTkLabel(

            bubble_frame,

            text=message,

            font=("Segoe UI", 14),

            fg_color=USER_BUBBLE,

            text_color="white",

            corner_radius=20,

            padx=15,

            pady=10,

            wraplength=450,

            justify="left"
        )

        bubble.pack(anchor="e", padx=10)

    # BOT MESSAGE
    else:

        bubble = ctk.CTkLabel(

            bubble_frame,

            text=message,

            font=("Segoe UI", 14),

            fg_color=BOT_BUBBLE,

            text_color="white",

            corner_radius=20,

            padx=15,

            pady=10,

            wraplength=450,

            justify="left"
        )

        bubble.pack(anchor="w", padx=10)

# =========================================================
# CLEAR CHAT
# =========================================================
def clear_chat():

    for widget in chat_frame.winfo_children():

        widget.destroy()

    add_message(
        "Welcome to School Helpdesk Bot!",
        "bot"
    )

# =========================================================
# CLEAR CHAT BUTTON
# =========================================================
clear_button = ctk.CTkButton(

    sidebar,

    text="New Chat",

    corner_radius=15,

    command=clear_chat
)

clear_button.pack(pady=10)

# =========================================================
# GENERATE RESPONSE
# =========================================================
def generate_response(message):

    lower_message = message.lower()

    # KNOWLEDGE BASE
    if lower_message in knowledge_base:

        return knowledge_base[lower_message]

    # AI CLASSIFIER
    features = extract_features(message, vocab)

    prob_dist = classifier.prob_classify(features)

    intent = prob_dist.max()

    confidence = prob_dist.prob(intent)

    if confidence < 0.5:

        return get_response("fallback")

    return get_response(intent)

# =========================================================
# SEND MESSAGE
# =========================================================
def send_message():

    message = user_input.get().strip()

    if message == "":
        return

    # SHOW USER MESSAGE
    add_message(message, "user")

    # CLEAR INPUT
    user_input.delete(0, tk.END)

    # TYPING INDICATOR
    typing_label = ctk.CTkLabel(

        chat_frame,

        text="Bot is typing...",

        font=("Segoe UI", 12),

        text_color="gray"
    )

    typing_label.pack(

        anchor="w",

        padx=20,

        pady=5
    )

    # BOT RESPONSE
    def show_response():

        typing_label.destroy()

        response = generate_response(message)

        add_message(response, "bot")

    root.after(1000, show_response)

# =========================================================
# SEND BUTTON
# =========================================================
send_button = ctk.CTkButton(

    input_frame,

    text="Send",

    width=120,

    height=45,

    corner_radius=20,

    font=("Segoe UI", 15, "bold"),

    command=send_message
)

send_button.pack(

    side="right",

    padx=(0, 10),

    pady=10
)

# =========================================================
# ENTER KEY SUPPORT
# =========================================================
root.bind(

    "<Return>",

    lambda event: send_message()
)

# =========================================================
# INITIAL MESSAGE
# =========================================================
add_message(

    "Welcome to the School Helpdesk Assistant!",

    "bot"
)


root.mainloop()