# log in for the number guessing game
y = input("Enter your name:\t")
z= int(input("Enter your age(year):\t"))
if z < 13:
    print("You cannot play this game as you may get addicted to it.")
else:
    print("Welcome to the number guessing game", y)
    # ask_level= input("Do you want to play the easy level or hard level? (e/h):\t")
    # if ask_level == 'h':
# Number Guessing Game
    import random
    x= random.randint(1, 100)
    i_1= int(input("Guess a number between 1 and 100:\t"))
    while i_1 != x:
        if i_1 < x:
            print("Your guess is too low. Try again.")
            i_1 = int(input("Guess a number between 1 and 100:\t"))
        elif i_1 > x:
            print("Your guess is too high. Try again.")
            i_1 = int(input("Guess a number between 1 and 100:\t"))
    else:
        print("Congratulations! You guessed the number correctly.")