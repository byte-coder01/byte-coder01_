import tkinter as tk
import random
import time


class F1ReactionApp:
    def __init__(self, root):
        self.root = root
        self.root.title("🏎️ F1 Launch Reaction")
        self.root.geometry("650x750")
        self.root.configure(bg="#0d0d0d")
        self.root.resizable(False, False)

        # Game state
        self.game_active = False
        self.clutch_held = False
        self.lights_active = False
        self.start_time = None
        self.best_time = None
        self.light_after_ids = []

        # Prevent Enter key auto-repeat
        self.enter_held = False

        # =================================================
        # TITLE
        # =================================================

        tk.Label(
            root,
            text="🏎️ F1 LAUNCH REACTION",
            font=("Arial", 30, "bold"),
            fg="#e10600",
            bg="#0d0d0d"
        ).pack(pady=(25, 5))

        tk.Label(
            root,
            text="Hold CLUTCH / ENTER • Wait for lights out • Release!",
            font=("Arial", 14),
            fg="white",
            bg="#0d0d0d"
        ).pack(pady=(0, 25))

        # =================================================
        # F1 LIGHTS
        # =================================================

        lights_frame = tk.Frame(
            root,
            bg="#202020",
            padx=20,
            pady=20
        )
        lights_frame.pack()

        self.lights = []

        for i in range(5):

            canvas = tk.Canvas(
                lights_frame,
                width=90,
                height=90,
                bg="#202020",
                highlightthickness=0
            )

            canvas.grid(
                row=0,
                column=i,
                padx=5
            )

            circle = canvas.create_oval(
                10,
                10,
                80,
                80,
                fill="#250000",
                outline="#555555",
                width=3
            )

            self.lights.append(
                (canvas, circle)
            )

        # =================================================
        # STATUS
        # =================================================

        self.status = tk.Label(
            root,
            text="Press START to prepare",
            font=("Arial", 17, "bold"),
            fg="white",
            bg="#0d0d0d"
        )

        self.status.pack(pady=30)

        # =================================================
        # RESULT
        # =================================================

        self.result = tk.Label(
            root,
            text="",
            font=("Arial", 28, "bold"),
            fg="#00ff55",
            bg="#0d0d0d"
        )

        self.result.pack(pady=5)

        # =================================================
        # CLUTCH BUTTON
        # =================================================

        self.clutch_button = tk.Button(
            root,
            text="CLUTCH",
            font=("Arial", 25, "bold"),
            bg="#333333",
            fg="white",
            activebackground="#555555",
            activeforeground="white",
            relief="raised",
            bd=6,
            width=12,
            height=2,
            cursor="hand2"
        )

        self.clutch_button.pack(pady=25)

        # Mouse controls
        self.clutch_button.bind(
            "<ButtonPress-1>",
            self.clutch_pressed
        )

        self.clutch_button.bind(
            "<ButtonRelease-1>",
            self.clutch_released
        )

        # =================================================
        # START BUTTON
        # =================================================

        self.start_button = tk.Button(
            root,
            text="START RACE",
            font=("Arial", 17, "bold"),
            bg="#e10600",
            fg="white",
            activebackground="#ff3030",
            activeforeground="white",
            relief="flat",
            padx=35,
            pady=12,
            command=self.start_race,
            cursor="hand2"
        )

        self.start_button.pack()

        # =================================================
        # BEST TIME
        # =================================================

        self.best_label = tk.Label(
            root,
            text="🏆 Best Launch: --",
            font=("Arial", 15, "bold"),
            fg="#aaaaaa",
            bg="#0d0d0d"
        )

        self.best_label.pack(pady=20)

        # =================================================
        # KEYBOARD CONTROLS
        # =================================================

        self.root.bind(
            "<KeyPress-Return>",
            self.enter_pressed
        )

        self.root.bind(
            "<KeyRelease-Return>",
            self.enter_released
        )

    # =====================================================
    # RESET LIGHTS
    # =====================================================

    def reset_lights(self):

        for canvas, circle in self.lights:
            canvas.itemconfig(
                circle,
                fill="#250000"
            )

    # =====================================================
    # START RACE
    # =====================================================

    def start_race(self):

        if self.game_active:
            return

        self.game_active = True
        self.clutch_held = False
        self.lights_active = False
        self.start_time = None
        self.enter_held = False

        self.result.config(
            text=""
        )

        self.reset_lights()

        self.status.config(
            text="HOLD THE CLUTCH / ENTER!",
            fg="#ffcc00"
        )

        self.start_button.config(
            state="disabled"
        )

        # Wait for player to hold clutch
        self.root.after(
            100,
            self.check_clutch
        )

    # =====================================================
    # CHECK CLUTCH
    # =====================================================

    def check_clutch(self):

        if not self.game_active:
            return

        if self.clutch_held:

            self.status.config(
                text="CLUTCH HELD — GET READY...",
                fg="#00ccff"
            )

            self.start_lights()

        else:

            self.status.config(
                text="HOLD THE CLUTCH / ENTER!",
                fg="#ffcc00"
            )

            self.root.after(
                100,
                self.check_clutch
            )

    # =====================================================
    # START LIGHT SEQUENCE
    # =====================================================

    def start_lights(self):

        if self.lights_active:
            return

        self.lights_active = True

        # =============================================
        # SLOWER F1-STYLE LIGHT SEQUENCE
        # =============================================

        # One light every 1 second
        light_interval = 1000

        for i in range(5):

            after_id = self.root.after(
                light_interval * i,
                lambda i=i: self.turn_on_light(i)
            )

            self.light_after_ids.append(
                after_id
            )

        # =============================================
        # RANDOM LIGHTS-OUT DELAY
        # =============================================

        # After the fifth light, wait between
        # 1 and 3 seconds before lights go out.
        final_delay = random.randint(
            1000,
            3000
        )

        # Five lights take 4 seconds to finish appearing.
        after_id = self.root.after(
            4000 + final_delay,
            self.lights_out
        )

        self.light_after_ids.append(
            after_id
        )

    # =====================================================
    # TURN ON LIGHT
    # =====================================================

    def turn_on_light(self, index):

        if not self.game_active:
            return

        canvas, circle = self.lights[index]

        canvas.itemconfig(
            circle,
            fill="#ff0000"
        )

    # =====================================================
    # LIGHTS OUT
    # =====================================================

    def lights_out(self):

        if not self.game_active:
            return

        # Turn all lights off
        self.reset_lights()

        self.status.config(
            text="GO! RELEASE CLUTCH / ENTER!",
            fg="#00ff44"
        )

        # Start reaction timer
        self.start_time = time.perf_counter()

    # =====================================================
    # MOUSE CLUTCH PRESS
    # =====================================================

    def clutch_pressed(self, event=None):

        if not self.game_active:
            return

        self.clutch_held = True

        self.clutch_button.config(
            bg="#e10600",
            relief="sunken"
        )

    # =====================================================
    # MOUSE CLUTCH RELEASE
    # =====================================================

    def clutch_released(self, event=None):

        self.clutch_held = False

        self.clutch_button.config(
            bg="#333333",
            relief="raised"
        )

        if not self.game_active:
            return

        self.process_release()

    # =====================================================
    # ENTER PRESSED
    # =====================================================

    def enter_pressed(self, event=None):

        # Ignore keyboard auto-repeat
        if self.enter_held:
            return

        self.enter_held = True

        if not self.game_active:
            return

        self.clutch_held = True

        self.clutch_button.config(
            bg="#e10600",
            relief="sunken"
        )

    # =====================================================
    # ENTER RELEASED
    # =====================================================

    def enter_released(self, event=None):

        if not self.enter_held:
            return

        self.enter_held = False

        if not self.game_active:
            return

        self.clutch_held = False

        self.clutch_button.config(
            bg="#333333",
            relief="raised"
        )

        self.process_release()

    # =====================================================
    # PROCESS CLUTCH RELEASE
    # =====================================================

    def process_release(self):

        # Player released before lights out
        if self.start_time is None:

            self.false_start()

            return

        # Calculate reaction time
        reaction_time = (
            time.perf_counter()
            - self.start_time
        ) * 1000

        self.finish_race(
            reaction_time
        )

    # =====================================================
    # FALSE START
    # =====================================================

    def false_start(self):

        self.game_active = False
        self.lights_active = False
        self.clutch_held = False
        self.enter_held = False

        self.cancel_timers()

        self.reset_lights()

        self.status.config(
            text="⚠️ JUMP START!",
            fg="#ff3333"
        )

        self.result.config(
            text="PENALTY",
            fg="#ff3333"
        )

        self.clutch_button.config(
            bg="#333333",
            relief="raised"
        )

        self.start_button.config(
            state="normal",
            text="TRY AGAIN"
        )

    # =====================================================
    # FINISH RACE
    # =====================================================

    def finish_race(self, reaction_time):

        self.game_active = False
        self.lights_active = False
        self.clutch_held = False
        self.enter_held = False

        self.cancel_timers()

        self.result.config(
            text=f"{reaction_time:.0f} ms",
            fg="#00ff55"
        )

        message = self.get_result_message(
            reaction_time
        )

        self.status.config(
            text=message,
            fg="white"
        )

        # Update best time
        if (
            self.best_time is None
            or reaction_time < self.best_time
        ):

            self.best_time = reaction_time

            self.best_label.config(
                text=f"🏆 Best Launch: {reaction_time:.0f} ms",
                fg="#ffcc00"
            )

        self.clutch_button.config(
            bg="#333333",
            relief="raised"
        )

        self.start_button.config(
            state="normal",
            text="RACE AGAIN"
        )

    # =====================================================
    # RESULT MESSAGE
    # =====================================================

    def get_result_message(self, time_ms):

        if time_ms < 100:
            return "🔥 PERFECT LAUNCH! ABSOLUTELY INSANE!"

        elif time_ms < 150:
            return "🏎️ ELITE F1 REACTION!"

        elif time_ms < 200:
            return "⚡ FANTASTIC LAUNCH!"

        elif time_ms < 250:
            return "🔥 VERY QUICK!"

        elif time_ms < 300:
            return "👍 SOLID START!"

        elif time_ms < 400:
            return "😐 YOU CAN LAUNCH FASTER!"

        else:
            return "🐌 SLOW GETAWAY! PRACTICE MORE!"

    # =====================================================
    # CANCEL TIMERS
    # =====================================================

    def cancel_timers(self):

        for timer in self.light_after_ids:

            try:
                self.root.after_cancel(timer)

            except tk.TclError:
                pass

        self.light_after_ids.clear()


# =========================================================
# MAIN PROGRAM
# =========================================================

if __name__ == "__main__":

    root = tk.Tk()

    app = F1ReactionApp(root)

    root.mainloop()
