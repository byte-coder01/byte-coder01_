﻿# Importing time package
import time
#Programme for Password checker
# Using - for seperating
print("-" * 50)
print("Password Checker")
# Using - for seperating
print("-" * 50)
# Asking the name of the user
name_1=str(input("Enter Your Name:\t"))
# Using - for seperating
print("-" * 50)
print("Hello!!",name_1,"Welcome to Password Checker")
# Using - for seperating
print("-" * 50)
# Asking User for the input of the password to check it's strength
password_ask = input("Enter Your Password:\t")
#Making a Variable Score Which Checks the Strength of the User's Password
Score = int(0)
#Checking the minimum length of passwrod to be strong
count_password = len(password_ask)          
# Defining special characters for checking
special_chara = set("!@#$%^&*()-_=+[]{};:'\",.<>?/\\|`~")
# Counting special characters in password
special_count = sum(1 for char in password_ask if char in special_chara)
# Counting numbers in the password 
number_count = sum(1 for char in password_ask if char in special_chara)
# Check password length
if count_password >=16 :
    Score += 4
    # Count special characters
    if special_count >= 5: 
        Score += 4
    elif special_count in range(3,5):
        Score +=2
    elif special_count in range(1,3):
        Score += 1
    else:
        Score -= 2
    # Count numbers in Password
    if number_count >= 3: 
        Score += 4
    elif number_count == 2:
        Score +=2
    elif number_count == 1:
        Score += 1
    else:
        Score -= 2
elif count_password in (14, 15):
    Score += 2
    # Count special characters
    if special_count >= 4: 
        Score += 4
    elif special_count == 3:
        Score +=2
    elif special_count in (1,2):
        Score += 1
    else:
        Score -= 2
    # Count numbers in Password
    if number_count >= 3: 
        Score += 4
    elif number_count == 2:
        Score +=2
    elif number_count == 1:
        Score += 1
    else:
        Score -= 2
elif count_password in (12, 13):
    Score += 1
    # Count special characters
    if special_count >= 4: 
        Score += 4
    elif special_count == 3:
        Score +=2
    elif special_count in (1,2):
        Score += 1
    else:
        Score -= 2
    # Count numbers in Password
    if number_count >= 3: 
        Score += 4
    elif number_count == 2:
        Score +=2
    elif number_count == 1:
        Score += 1
    else:
        Score -= 2
else:
    # Using - for seperating
    print("-" * 50)
    print("Password too Short To be Checked")
    # Using - for seperating
    print("-" * 50)
    exit()
print("Evaluating the Strength of the Password", end="", flush=True)
for _ in range(5):
    time.sleep(1)
    print(".", end="", flush=True)
time.sleep(1)
# Using - for seperating
print("\n" + "-" * 50)
# Calculating the report for the password in percentage
percentage = (Score / 12) * 100
print(f"Password Strength Percentage: {percentage:.2f}%")
if percentage >= 90:
    print("Status: Bulletproof ✓")
elif percentage in range(70,90):
    print("Status: Strong ✓")
elif percentage in range(60,70):
    print("Status: Moderate")
else:
    print("Status: Weak ✗")
# Using - for seperating
print("-" * 50)
time.sleep(120)
# End of This Project :)